file = open('file_example.txt', 'r')
contents = file.read()
print(contents)
file.close()