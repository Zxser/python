import echo

print("After import, __name__ is", __name__, \
	"and echo.__name__ is", echo.__name__)
