>>> blue_crab = Arthropod('Callinectes sapidus', 0, 0)
>>> print blue_crab
(Callinectes sapidus, 0, 0)
