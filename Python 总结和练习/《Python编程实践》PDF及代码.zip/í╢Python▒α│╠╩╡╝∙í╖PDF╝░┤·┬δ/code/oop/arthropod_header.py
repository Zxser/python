class Arthropod(Organism):
    pass
